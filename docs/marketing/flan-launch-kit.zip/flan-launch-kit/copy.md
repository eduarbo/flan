# FLAN · Textos EN / ES

Borradores preparados; no publicados ni enviados. Origen: `viewer/marketing/copy.json`.

## ES

### Reddit / comunidad · versión en español

**[ad] Flan: un teclado dividido de código abierto con marcos magnéticos**

Soy Eduardo, el diseñador de Flan.

Es un teclado dividido de perfil bajo, con cuatro distribuciones: 36, 42, 46 y 54 teclas. Quería que su apariencia también fuera parte del proyecto: cuatro carcasas, seis diseños de marco magnético para las pantallas, 31 temas y colores por tecla. El explorador 3D permite probar una combinación, mirar sus piezas y descargar los archivos del prototipo.

Está diseñado para switches Choc v1 con sockets hot-swap, controladores nice!nano v2, ZMK y pantallas nice!view. Hay fuentes de KiCad y FreeCAD, Gerbers, archivos de impresión y firmware compilado. Flan36 conserva las posiciones de teclas de Piantor y usa keycaps KLP Lamé; los créditos están en el repositorio.

Las imágenes son renders CAD del prototipo digital.

Explorador: https://flankbd.com/explore/?size=flan36&theme=flan&case=rim&keys=original&frame=talavera
Fuentes y guía: https://github.com/eduarbo/flan

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Usa esta versión en comunidades de habla hispana que permitan proyectos. Para r/ErgoMechKeyboards está preparada la versión EN, con prefijo [ad] y flair de vendor; no más de una promoción cada 14 días.

### Instagram · texto del carrusel

**Hazlo tuyo. Este es Flan.**

Este es Flan, un teclado dividido y de código abierto que estoy construyendo: cuatro tamaños, marcos magnéticos para las pantallas y una apariencia que puedes hacer tuya. Desliza para ver las distribuciones y las capas.

Explora el modelo CAD y descarga los archivos de código abierto en flankbd.com.

¿Cuántas teclas tendría el tuyo: 36, 42, 46 o 54?

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#TecladosMecanicos #SplitKeyboard #DIYKeyboard #OpenSourceHardware #FlanKeyboard

Uso: Sube carousel-es-1 a carousel-es-6, en orden. Coloca flankbd.com como enlace del perfil; una URL en el texto de Instagram no equivale a un enlace pulsable.

### Instagram · Reel / YouTube Short

**Flan en seis escenas**

Un teclado dividido para hacerlo tuyo. Este es Flan: archivos abiertos, cuatro tamaños y marcos magnéticos para las pantallas.

El modelo CAD muestra cómo encajan la carcasa, las teclas y los marcos de pantalla.

Explora el diseño en flankbd.com.

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#TecladosMecanicos #DIYKeyboard #FlanKeyboard

Uso: Archivo: teaser-es.mp4, vertical 1080 × 1920, 30 segundos y sin audio; el texto ya está dentro del video. Subtítulos opcionales: teaser-es.srt. No representa hardware funcionando.

### YouTube · video de presentación

**Flan: así diseñé mi primer teclado dividido de código abierto**

Soy Eduardo y este es Flan: un diseño de teclado dividido y de perfil bajo, con cuatro tamaños y marcos magnéticos. En el explorador 3D puedes comparar las distribuciones y separar las capas de cada mitad.

Explora: https://flankbd.com/
Fuentes, créditos y guía: https://github.com/eduarbo/flan

Todas las imágenes del teclado en esta presentación son renders CAD.

Diseño: Eduardo Ruiz. Las posiciones de Flan36 siguen Piantor de beekeeb. Créditos y licencias completos en el repositorio.

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#TecladosMecanicos #DIYKeyboard #OpenSourceHardware

Uso: Portada: youtube-es.png. El guion para grabar el video largo está en video.md; el teaser ya entregado dura 30 segundos. Los capítulos se añaden con los tiempos reales de la edición final.

### Grupo de teclados / makers

**Este es Flan**

Hola, soy Eduardo. Estoy diseñando Flan, un teclado dividido de código abierto con carcasas personalizables y marcos magnéticos para las pantallas.

Puedes explorar el modelo CAD y descargar los archivos en https://flankbd.com/. ¿Qué distribución elegirías?

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Borrador para el espacio de proyectos autorizado por cada grupo. No se ha verificado membresía ni permiso de administradores y no se ha enviado ningún mensaje.

### Creador / medio · propuesta preparada

**Flan: un teclado abierto con marcos de pantalla intercambiables**

Hola, soy Eduardo Ruiz, el diseñador de Flan. Es un teclado dividido de código abierto con cuatro tamaños, carcasas imprimibles y marcos magnéticos para las pantallas. Tiene un explorador 3D para personalizarlo y descargar los archivos del prototipo.

El kit de medios incluye renders CAD de los cuatro tamaños, las carcasas imprimibles y los marcos magnéticos.

Proyecto: https://flankbd.com/
Fuentes: https://github.com/eduarbo/flan
Material visual: https://flankbd.com/marketing/

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Eduardo

Uso: Borrador sin enviar. Personaliza el motivo concreto de relevancia para el destinatario al autorizar el contacto. No promete una muestra, patrocinio, fecha ni resultados de pruebas.

### Biografía · Instagram

**Flan Keyboard**

Teclado dividido de código abierto.
36, 42, 46 o 54 teclas.
Hazlo tuyo en 3D.

Uso: Enlace del perfil: https://flankbd.com/. No se han creado cuentas ni se ha verificado la disponibilidad de un handle.

### Respuesta fijada · archivos del diseño

**Dónde conseguir los archivos**

El explorador en https://flankbd.com/explore/ incluye la lista de piezas, los archivos de PCB, el kit de impresión y el firmware para tu distribución. Las imágenes son renders CAD del prototipo. Puedes reportar un problema del diseño o la configuración en https://github.com/eduarbo/flan/issues.

Render CAD de Flan por Eduardo Ruiz con keycaps KLP Lamé de braindefender, colocadas y coloreadas. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Úsala cuando alguien interprete la presentación como un producto terminado o una venta.

## EN

### Reddit · r/ErgoMechKeyboards

**[ad] Flan: an open-source split keyboard with magnetic display frames**

I’m Eduardo, the designer of Flan.

Flan is a low-profile split keyboard with four layouts: 36, 42, 46 and 54 keys. I wanted the appearance to be something you can change as part of the build: four case styles, six magnetic display-frame designs, 31 themes and per-key colors. The browser explorer lets you try a combination, inspect its parts and download the corresponding prototype files.

The intended hardware is Choc v1 hot-swap, nice!nano v2 controllers, ZMK and nice!view displays. Editable KiCad and FreeCAD sources, Gerbers, print files and compiled firmware are available. Flan36 follows the Piantor key positions; keycaps use KLP Lamé. Credits and licenses are in the repository.

These images are CAD renders of the digital prototype.

Explorer: https://flankbd.com/explore/?size=flan36&theme=flan&case=rim&keys=original&frame=talavera
Source and build guide: https://github.com/eduarbo/flan

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Prepared draft. Apply the vendor flair for this promotional post. The verified rule allows at most one promotional post per rolling 14 days and four promotional comments per rolling seven days. No cross-post blast. Check the rules and account eligibility again when posting.

### Instagram · carousel caption

**Make it yours. Meet Flan.**

This is Flan, an open-source split keyboard I’m building: four sizes, magnetic display frames and a look you can make your own. Swipe to see the layouts and the layers.

Explore the CAD model and download the open-source files at flankbd.com.

Which layout would you try: 36, 42, 46 or 54 keys?

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#SplitKeyboard #MechanicalKeyboard #DIYKeyboard #OpenSourceHardware #FlanKeyboard

Uso: Use carousel-en-1 through carousel-en-6, in order. The caption URL is plain text: put the real destination in the profile link. Hashtags are descriptive choices, not a reach guarantee.

### Instagram · Reel / YouTube Short

**Flan in six frames**

A split keyboard you can make your own. This is Flan: open-source files, four sizes and magnetic display frames.

The CAD model shows how the case, keys and display frames fit together.

Explore the design at flankbd.com.

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#SplitKeyboard #DIYKeyboard #FlanKeyboard

Uso: Upload teaser-en.mp4: 1080 × 1920, 30 seconds, silent, text already visible. Optional captions: teaser-en.srt. This is a rendered teaser, not footage of working hardware. Use a profile link on IG; on YouTube say the domain aloud if adding narration.

### YouTube · first design video

**Flan: designing my first open-source split keyboard**

I’m Eduardo, and this is Flan: an open-source, low-profile split keyboard design with four sizes and magnetic display frames. The 3D explorer lets you compare layouts and take each half apart.

Explore: https://flankbd.com/
Source, credits and build guide: https://github.com/eduarbo/flan

All keyboard visuals in this design preview are CAD renders.

Design: Eduardo Ruiz. Flan36 key positions follow Piantor by beekeeb. Full third-party attribution and licensing are in the repository.

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

#SplitKeyboard #DIYKeyboard #OpenSourceHardware

Uso: Use youtube-en.png for the design-video thumbnail. The longer video is a recording script in video.md; the delivered playable teaser is 30 seconds. Add chapters only after the final recording has actual timings.

### Community / maker group

**Meet Flan**

Hi, I’m Eduardo and I’m sharing a keyboard I designed: Flan, an open-source split with customizable cases and magnetic display frames.

Explore the CAD model and download the files at https://flankbd.com/. Which layout would you choose?

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Use only in a group whose rules permit project promotion. Group access and admin permission are not verified; no message has been sent. Do not send unsolicited individual DMs.

### KBD.news · prepared editorial pitch

**Flan: open-source split keyboard with interchangeable magnetic display frames**

Hi, I’m Eduardo Ruiz, the designer of Flan. I’m sharing an open-source keyboard project that may fit your prototype/design coverage.

Flan combines four split layouts (36/42/46/54 keys), four printable case styles and six magnetic display-frame designs with a browser-based 3D explorer. The source includes KiCad, FreeCAD, Gerbers, printable parts and ZMK firmware.

The media kit includes CAD renders of all four layouts, printable cases and magnetic display frames.

Project: https://flankbd.com/
Source: https://github.com/eduarbo/flan
Images and project summary: https://flankbd.com/marketing/

Thanks,
Eduardo

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Draft only. The publisher’s contact page invites keyboard-project submissions; direct page access was blocked during this review, so verify the current contact method before sending. No sample, sponsorship, launch date or coverage commitment is offered.

### Profile bio · Instagram

**Flan Keyboard**

Open-source split keyboard.
36, 42, 46 or 54 keys.
Make it yours in 3D.

Uso: Profile link: https://flankbd.com/. Existing account names, handles and access have not been verified; this is copy, not a created account.

### Pinned reply · design files

**Where to get the files**

The explorer at https://flankbd.com/explore/ includes the parts list, PCB files, print kit and firmware for your layout. The images are CAD renders of the prototype. Report a design or configuration issue at https://github.com/eduarbo/flan/issues.

Flan CAD render by Eduardo Ruiz with KLP Lamé keycaps by braindefender, placed and colored. CC BY-SA 4.0 · https://creativecommons.org/licenses/by-sa/4.0/

Uso: Use as the first clarification when a post is mistaken for a finished product or sale.
