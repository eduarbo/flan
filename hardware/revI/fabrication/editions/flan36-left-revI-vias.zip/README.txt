FLAN36 revI prototype candidate — left · Vías edition
Same copper, mask, outline and drills as the base package; only the back silkscreen differs.
Two copper layers, 1.6 mm FR4, nominal 1 oz copper. Inspect Gerber and drill previews.
Digital DRC/ERC/netlist checks passed. This is not a physically qualified build kit.
Build, BOM and hardware acceptance: https://github.com/eduarbo/flan36/blob/main/docs/build.md
